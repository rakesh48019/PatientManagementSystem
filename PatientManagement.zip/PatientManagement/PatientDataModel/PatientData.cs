﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PatientDataModel
{
    /// <summary>
    /// Stores the Patient data
    /// </summary>
    public class PatientData 
    {
        private double _value1=0.0;
        private double _value2=0.0;
        private int _value3;

        public double Value1
        {
            get { return _value1; }
            set
            {
                _value1 = value;
               // OnPropertyChanged("Value1");
            }
        }

        public double Value2
        {
            get { return _value2; }
            set
            {
                _value2 = value;
                //OnPropertyChanged("Value2");
            }
        }

        public int Value3
        {
            get { return _value3; }
            set
            {
                _value3 = value;
                //OnPropertyChanged("Value3");
            }
        }

        //public event PropertyChangedEventHandler PropertyChanged;

        
        //protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        //{
        //    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //}
    }
}
