﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientManagementGUI
{
    public class UIProgressEventArgs:EventArgs
    {
        public string Description { get; }
        public UIProgressEventArgs(string msg)
        {
            Description = msg;
        }
    }
}
