﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Input;
using PatientDataModel;
using PatientManagementGUI.Annotations;
using PatientManagementGUI.Commands;
using StorageManagement.Contracts;

namespace PatientManagementGUI.ViewModel
{
    /// <summary>
    /// View model for Patient value screen
    /// </summary>
    public class PatientValuesInputVm : INotifyPropertyChanged
    {

        private PatientData _patientData;
        private ICommand _processPatientData;
        private string _status;

        //keeping it protected so that in testable class during unit tests we can inject mock in it.
        //if I inject it through constructor then the responsibility of choosing storage manager will move to UI side which I want to avoid.
        protected IStorageManager _storageManager;

        public event PropertyChangedEventHandler PropertyChanged;

        public event EventHandler<UIProgressEventArgs> UIProgressDescription;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// 
        /// </summary>
        public PatientValuesInputVm()
        {
            _patientData = new PatientData();

            _processPatientData = new ApplicationCommand(ProcessData, CanProcessData);
        }

        /// <summary>
        /// Created this virtual method so that during unit testing we can override this view model class to create a testable
        /// and inject mocked object 
        /// </summary>
        /// <returns></returns>
        protected virtual void GetStorageManager()
        {
            var storageFactory = new StorageFactory();
            _storageManager = storageFactory.GetStorageManager(StorageType.TextFileStorage);
            _storageManager.ProgressNotification += storageManager_ProgressNotification;
        }


        /// <summary>
        /// Handles the Progress send by storage management
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void storageManager_ProgressNotification(object sender, StorageProgressNotification e)
        {
            //Progress notification can be mapped to UI status and can be displayed in UI 
            //Lack of time constraint only displaying the description.
            UIProgressDescription?.Invoke(this, new UIProgressEventArgs(e.Description));
        }


        private void ProcessData(object obj)
        {
            //initialize storage manager 
            GetStorageManager();
            _storageManager.WriteDataToStorage(_patientData);
            
        }

        private bool CanProcessData(object param)
        {
            return true;
        }

        public string TxtValue1
        {
            get
            {
                return _patientData.Value1.ToString("N3");
            }
            set
            {
                //TODO: Logic of truncating decimal point can be moved to common utility class
                var temp = Double.Parse(value);
                temp = Math.Truncate(temp * 1000) / 1000;
                _patientData.Value1 = temp;
                OnPropertyChanged("TxtValue1");
            }
        }

        public string TxtValue2
        {
            get
            {
                return _patientData.Value2.ToString("N3"); ;
            }
            set
            {
                //TODO: Logic of truncating decimal point can be moved to common utility class
                var temp = Double.Parse(value);
                temp = Math.Truncate(temp * 1000) / 1000;
                _patientData.Value2 = temp;
                OnPropertyChanged("TxtValue2");
            }
        }

        public string TxtValue3
        {
            get
            {
                return _patientData.Value3.ToString();
            }
            set
            {
                _patientData.Value3 = int.Parse(value);
                OnPropertyChanged("TxtValue3");
            }
        }


        public ICommand ProcessPatientDataCommand
        {
            get { return _processPatientData; }
            set { _processPatientData = value; }
        }
    }

}
