﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PatientManagementGUI.ViewModel;

namespace PatientManagementGUI.Views
{
    /// <summary>
    /// Interaction logic for PatientValuesInput.xaml
    /// </summary>
    public partial class PatientValuesInput : UserControl
    {
        
        private PatientValuesInputVm _patientValuesInputVm;
        public PatientValuesInput()
        {
            _patientValuesInputVm=new PatientValuesInputVm();
            _patientValuesInputVm.UIProgressDescription += patientValuesInputVm_UIProgressDescription;
            this.DataContext = _patientValuesInputVm;
            InitializeComponent();
        }

        private void patientValuesInputVm_UIProgressDescription(object sender, UIProgressEventArgs e)
        {
            MessageBox.Show(e.Description);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(TxtValue3.Text, "[^0-9]"))
            {
                MessageBox.Show("Text box expects only Integers");
                TxtValue3.Text = TxtValue3.Text.Remove(TxtValue3.Text.Length - 1);
            }
        }

    }
}
