﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageManagement.Contracts
{
    /// <summary>
    /// Interface for creating factory for storage
    /// In future you might also want to store it in DB or xml file 
    /// </summary>
    public interface IStorageFactory
    {
        IStorageManager GetStorageManager(StorageType storageType);
    }
}
