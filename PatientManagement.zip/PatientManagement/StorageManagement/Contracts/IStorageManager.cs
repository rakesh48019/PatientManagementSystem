﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDataModel;

namespace StorageManagement.Contracts
{
    public interface IStorageManager
    {
        void WriteDataToStorage(PatientData patientData);

        PatientData ReadDataFromStorage();

        event EventHandler<StorageProgressNotification> ProgressNotification;
    }
}
