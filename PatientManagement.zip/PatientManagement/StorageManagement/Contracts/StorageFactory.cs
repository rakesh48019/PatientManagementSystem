﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageManagement.Contracts
{
    public class StorageFactory : IStorageFactory
    {
        /// <summary>
        /// Gets the storage manager from factory
        /// </summary>
        /// <param name="storageType"></param>
        /// <returns></returns>
        public IStorageManager GetStorageManager(StorageType storageType)
        {
            IStorageManager storageManager = default(IStorageManager);
            switch (storageType)
            {
                case StorageType.TextFileStorage:
                    storageManager = new TextFileStorage();
                    break;
                case StorageType.XmlFileStorage:
                    //create object for xml type storage
                    break;
                default:
                    //log if it does not match the type
                    break;

            }

            return storageManager;
        }
    }
}
