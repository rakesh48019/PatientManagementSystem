﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace StorageManagement.Contracts
{
    public class StorageProgressNotification : EventArgs
    {
        public StorageStatus Status { get; }

        public string Description { get; }

        public StorageProgressNotification(StorageStatus status,string description)
        {
            Status = status;
            Description = description;
        }
    }
}
