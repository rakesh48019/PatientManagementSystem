﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDataModel;
using StorageManagement.Contracts;

namespace StorageManagement
{
    /// <summary>
    /// 
    /// </summary>
    public class TextFileStorage : IStorageManager
    {
        private string _storagePath;

        public TextFileStorage()
        {
            _storagePath = GetHomeDirectory();
            _storagePath = Path.Combine(_storagePath, "werte.txt");// as given in the document file name is werte.txt
        }

        public event EventHandler<StorageProgressNotification> ProgressNotification;

        public PatientData ReadDataFromStorage()
        {
            //check if the file exists in the disk or not
            if (!File.Exists(_storagePath))
            {
                return null;
            }

            string str = File.ReadAllText(_storagePath);
            var splitValues = str.Split(',');
            var patientData = new PatientData();
            patientData.Value1 = Double.Parse(splitValues[0]);
            patientData.Value2 = Double.Parse(splitValues[1]);
            patientData.Value3 = int.Parse(splitValues[2]);
            return patientData;
        }

        public void WriteDataToStorage(PatientData patientData)
        {

            StorageProgressNotification progress;
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(patientData.Value1.ToString() + ",");
                stringBuilder.Append(patientData.Value2.ToString() + ",");
                stringBuilder.AppendLine(patientData.Value3.ToString());
                File.WriteAllText(_storagePath, stringBuilder.ToString());
                progress = new StorageProgressNotification(StorageStatus.Completed, "Storage completed ");
            }
            catch (Exception e)
            {
                progress = new StorageProgressNotification(StorageStatus.Error, e.Message);
            }
            if (ProgressNotification != null)
            {
                ProgressNotification.Invoke(this, progress);
            }
        }

        private string GetHomeDirectory()
        {
            DirectoryInfo info = new DirectoryInfo(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal));
            return info.Parent.Parent.FullName;
        }
    }
}
