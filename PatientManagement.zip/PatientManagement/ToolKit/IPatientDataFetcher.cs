﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDataModel;

namespace ToolKit
{
    /// <summary>
    /// THis interface can be used by third party software to fetch the Data from text file
    /// they can consume this tool kit in thier project to fetch the patient data
    /// </summary>
    public interface IPatientDataFetcher
    {
        PatientData GetData();
    }
}
