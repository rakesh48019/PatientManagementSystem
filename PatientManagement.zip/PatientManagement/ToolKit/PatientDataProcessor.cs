﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientDataModel;
using StorageManagement.Contracts;

namespace ToolKit
{
    /// <summary>
    /// THis class can be used by third party software to fetch the Data from text file
    /// they can consume this tool kit in thier project to fetch the patient data
    /// </summary>
    public class PatientDataProcessor : IPatientDataFetcher
    {

        public PatientData GetData()
        {
            var storageManager = GetStorageManager();
            return storageManager.ReadDataFromStorage();
        }

        private IStorageManager GetStorageManager()
        {
            var storageFactory = new StorageFactory();
            return storageFactory.GetStorageManager(StorageType.TextFileStorage);
        }
    }
}
